import { Component, OnInit } from '@angular/core';
import { SidebarEmitterService } from '../sidebar-emitter.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  status = false;
  constructor(private sidebarEmitterService:SidebarEmitterService) { }

  ngOnInit() {
  }

  manageSidebar(status){
       this.status = !status ;
      this.sidebarEmitterService.sidebarStatus(this.status);
  }

}
