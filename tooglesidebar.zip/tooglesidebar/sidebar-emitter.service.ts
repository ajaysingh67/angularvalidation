import { Injectable } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';

@Injectable()
export class SidebarEmitterService {
    @Output() checksidebarEmiter: EventEmitter<any>;
   
    constructor() {
        this.checksidebarEmiter = new EventEmitter();
    }

    public sidebarStatus(status: any): void {
        console.log('fdfsdf',status);
        this.checksidebarEmiter.emit(status);
    }
   
}
