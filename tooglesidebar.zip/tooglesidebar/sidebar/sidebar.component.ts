import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { SidebarEmitterService } from '../sidebar-emitter.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  toggle = false;
  @ViewChild('sidebar') sidebar: ElementRef;
  constructor(private sidebarEmitterService:SidebarEmitterService) { 
        this.sidebarEmitterService.checksidebarEmiter.subscribe(status=>{
        
            if(status){
              this.sidebar.nativeElement.classList.add("active") ;
            } else {
              this.sidebar.nativeElement.classList.remove("active") ;
            }
        }) ;
  }

  ngOnInit() {
  }

}
