import { Component, ElementRef, ViewChild } from '@angular/core';
import { SidebarComponent } from './sidebar/sidebar.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'demo';
  toggle = false;
  @ViewChild('sidebar') sidebar: ElementRef;
  @ViewChild('SidebarComponent') sidebarComponent:SidebarComponent ;

     opennav(toggle){
          
          this.toggle = !toggle; 
          console.log('sdasdas',this.toggle);
          // if(this.toggle){
          //   this.sidebar.nativeElement.classList.add("active") ;
          // } else {
          //   this.sidebar.nativeElement.classList.remove("active") ;
          // }

            this.sidebarComponent.opennav1(this.toggle);
          
     }
}
