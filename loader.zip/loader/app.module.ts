import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Injector } from '@angular/core';

import { AppComponent } from './app.component';
// MDB Module
import { MDBBootstrapModulesPro, MDBSpinningPreloader, ToastModule} from 'ng-uikit-pro-standard';
import { Routes, RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
// Routes
import { LoginComponent } from './components/RouteComponent/login/login.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { HeaderComponent } from './components/HelperComponent/header/header.component';
import { SidebarComponent } from './components/HelperComponent/sidebar/sidebar.component';

import { ValidationMessageComponent } from './shared/validation-message/validation-message.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ValidationmessageserviceService } from './service/validationmessageservice.service';
import { SharedService } from './service/shared.service';
import { InterceptedHttpService } from './service/interceptor/InterceptedHttp.service ';
import { HttpClientModule } from '@angular/common/http';
import { AuthGuard } from './service/interceptor/auth-guard.service';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { UsersService } from './service/users/users.service';
import { DatePipe } from '@angular/common';
import { LoaderComponent } from './components/HelperComponent/loader/loader.component';
import { LoaderInterceptorService } from './service/interceptor/loader-interceptor.service';
import { LoaderService } from './service/loader/loader.service';
import { AuthExpiredInterceptor } from './service/interceptor/auth-expired.interceptor';
import { BusinessUserDetailsComponent } from './components/RouteComponent/business-user-details/business-user-details.component';
import { ChatService } from './service/chat/chat.service';
import { Web3Service } from './service/web3/web3.service';
import { ToastService } from 'ng-uikit-pro-standard';
import { Web3ContractService } from './service/web3/web3-contracts';
import { TwoFactorAuthenticationService } from './service/twofactorauthentication/two-factor-authentication.service';
import { FiatDepositComponent } from './components/RouteComponent/fiat-deposit/fiat-deposit.component';
import { ChangedailylimitService } from './service/changelimit/changedailylimit.service';
import { IndividualKycLimits } from './service/individualKycService/individual.kyc.service';

import { ExchangeService } from './service/exchange/exchange.service';
import { GenerateTicketComponent } from './components/RouteComponent/generate-ticket/generate-ticket.component';
import { FiatInvoiceComponent } from './components/SingletonComponent/fiat-invoice/fiat-invoice.component';
import { BusinessKycComponent } from './components/RouteComponent/business-kyc/business-kyc.component';
import { MultisignService } from './service/multisign/multisign.service';

const route: Routes = [
  {path: '', component: LoginComponent, data: {title: 'Sign in'} },
  // { path: 'UserDetails/:id', component: UserDetailsComponent },
  {
    path: 'dashboard',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  }, {
    path: '',
    component: AdminLayoutComponent,
    children: [
        {
      path: '',
      loadChildren: './layouts/admin-layout/admin-layout.module#AdminLayoutModule'
  }]}


];

@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(route),
    MDBBootstrapModulesPro.forRoot(),
    ToastModule.forRoot()
  ],
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    SidebarComponent,
    AdminLayoutComponent,
    ValidationMessageComponent,
    LoaderComponent,
    BusinessUserDetailsComponent
   // BusinessKycComponent,
   // BusinessKycDetailsComponent,
  //  FiatInvoiceComponent,
   // GenerateTicketComponent
   // CasExchangeComponent
    // KycLimitsUpdateComponent,
  //  KycLimitComponent,
    // ChangedailylimitComponent,
    //CasPendingTransactionComponent,
  ],
  providers: [
    MDBSpinningPreloader,
    ValidationmessageserviceService,
    SharedService,
    LoaderService,
    UsersService,
    DatePipe,
    ChatService,
    AuthGuard,
    ToastService,
    Web3Service,
    TwoFactorAuthenticationService,
    Web3ContractService,
    IndividualKycLimits,
    ChangedailylimitService,
    ExchangeService,
    MultisignService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptedHttpService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoaderInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthExpiredInterceptor,
      multi: true,
      deps: [Injector, SharedService]
   },
    { provide: LocationStrategy,
      useClass: HashLocationStrategy,
    }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class AppModule { }
