import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedService } from 'src/app/service/shared.service';
import { LoaderService } from 'src/app/service/loader/loader.service';
import { ValidationmessageserviceService } from 'src/app/service/validationmessageservice.service';
import { ToastService, IMyOptions } from 'ng-uikit-pro-standard';
import { CurrencyType } from 'src/app/enums/currencyType.enum';
import { TransactionType } from 'src/app/enums/transactionType.enum';
import { TransactionMode, AccountStatus } from 'src/app/enums/transactionMode.enum';
import { OperationType } from 'src/app/enums/operationType.enum';
import { TransactionsService } from 'src/app/service/transactions/transactions.service';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { AddPaymentModel, CheckKycLimitModel } from 'src/app/models/add-payment';
import { AccountLedgerStatus } from 'src/app/enums/accountLedgerStatus.enum';
import * as _ from 'lodash';
import { Http } from '@angular/http';

@Component({
  selector: 'app-add-payment',
  templateUrl: './add-payment.component.html',
  styleUrls: ['./add-payment.component.scss']
})
export class AddPaymentComponent implements OnInit {
  selectedFiat: boolean = false;
  //limitCheck: CheckKycLimitModel;
  bank: string = null;
  amount:number=null;
  txId:string=null;
  fiatRefrenceNumber:string=null;
  payingWithCurrency:string=null;
  paymentModel: FormGroup;
  selected = false;
  currencyValue: any;
  optionsSelect: Array<any>;
  currentCurrency = 'CAS';
  selectedValue: any;
  checklimit:boolean=false;
  selectedTransactionMode = false;
  transactionModeValue: any;
  transactionModeSelect: Array<any>;
  currentTransactionMode = 'DEPOSIT';
  selectedTransactionModeValue: any;

  selectedTransactionType = false;
  transactionTypeValue: any;
  transactionTypeSelect: Array<any>;
  currentTransactionType = 'CREDIT';
  selectedTransactionTypeValue: any;

  selectedOperationType = false;
  operationTypeValue: any;
  operationTypeSelect: Array<any>;
  currentOperationType = 'CRYPTO';
  selectedOperationTypeValue: any;

  selectedAccountLedgerStatus = false;
  accountLedgerStatusValue: any;
  accountLedgerStatusSelect: Array<any>;
  currentAccountLedgerStatus = 'SUCCESS';
  selectedAccountLedgerStatusValue: any;
  CountriesOption: Array<any>;
  currentPayingWith: string;
  kycDetail:any;
//AccountLedgerStatus
paymentDate: string =null;
currencyType:any=null;
currentDate = new Date();
public FromDatePickerOptions: IMyOptions = {
  dateFormat: 'dd-mm-yyyy',
  minYear: 2010,
  maxYear: this.currentDate.getFullYear(),
  disableSince: {
      year: this.currentDate.getFullYear(),
      month: this.currentDate.getMonth() + 1,
      day: this.currentDate.getDate() + 1
  },
  closeAfterSelect: true
 };
  constructor(private fb: FormBuilder,private loaderService: LoaderService,private transactionsService: TransactionsService,
    private toasterService: ToastService,private _sharedservice: SharedService,private _router: Router,private route: ActivatedRoute,) {
    this.paymentModel = this.fb.group({
      email: new FormControl('', [ValidationmessageserviceService.emailValidator]),
      currencyType: new FormControl('', [Validators.required]),
      amount: new FormControl('', [Validators.required, ValidationmessageserviceService.nonzeroamount]),
      transactionMode: new FormControl('', [Validators.required]),
      transactionType: new FormControl('', [Validators.required]),
      operationType: new FormControl('', [Validators.required]),
      txId: new FormControl('', [Validators.required]),
      status: new FormControl('', [Validators.required]),
      fromAddressOrIban: new FormControl('', [Validators.required]),
      inhouse: new FormControl(''),
      twoFactorCode: new FormControl('', [Validators.required, ValidationmessageserviceService.onlynumber]),
      fiatRefrenceNumber: new FormControl(''),
      payingWithCurrency: new FormControl(''),
      paymentDate: new FormControl(''),
      bank: new FormControl('')
    });

 //   this.selectedcurrencytype = this.paymentModel.get('currencyType').value;
 //   console.log(this.selectedcurrencytype);
    this.amount = this.route.snapshot.queryParams['amount']? this.route.snapshot.queryParams['amount']: null;
    this.txId = this.route.snapshot.queryParams['txId']? this.route.snapshot.queryParams['txId']: null;
    this.fiatRefrenceNumber = this.route.snapshot.queryParams['fiatRefrenceNumber']? this.route.snapshot.queryParams['fiatRefrenceNumber']: null;
    this.payingWithCurrency = this.route.snapshot.queryParams['payingWithCurrency']? this.route.snapshot.queryParams['payingWithCurrency']: null;
    this.currencyType = this.route.snapshot.queryParams['currencyType']? this.route.snapshot.queryParams['currencyType']: null;
    let date =this.route.snapshot.queryParams['paymentDate']? this.route.snapshot.queryParams['paymentDate']: null;
    if(date!=null){
      this.paymentDate = date.split('-')[2]+'-'+date.split('-')[1]+'-'+date.split('-')[0];
    }
    if(this.currencyType=="EURO" || this.currencyType=="GBP" ){
      this.selectedFiat = true;
    }
    else{
      this.selectedFiat = false;
    }
    if(this.paymentDate!=null && this.fiatRefrenceNumber!=null){
      this.checkKyclimit(this.fiatRefrenceNumber);
    }
   }

  ngOnInit() {
    const currencyType = Object.keys(CurrencyType);
    const arr = [];
    currencyType.forEach((value, key) => {
      this.selected = false;
      this.currencyValue = value;
        if (value === this.currentCurrency) {
            this.selectedValue = value;
            this.selected = true;
        }
        arr.push({ value: this.currencyValue, label: this.currencyValue, selected: this.selected });
    });
    this.optionsSelect = arr;
    const transactionType = Object.keys(TransactionType);
    const arrtransactionType = [];
    transactionType.forEach((value, key) => {
      this.selectedTransactionType = false;
      this.transactionTypeValue = value;
        if (value === this.currentTransactionType) {
            this.selectedTransactionTypeValue = value;
            this.selectedTransactionType = true;
        }
         arrtransactionType.push({ value: this.transactionTypeValue, label: this.transactionTypeValue, selected: this.selectedTransactionType });
    });
    this.transactionTypeSelect = arrtransactionType;

    const transactionMode = Object.keys(TransactionMode);
    const arrtransactionMode = [];
    transactionMode.forEach((value, key) => {
      this.selectedTransactionMode = false;
      this.transactionModeValue = value;
        if (value === this.currentTransactionMode) {
            this.selectedTransactionModeValue = value;
            this.selectedTransactionMode = true;
        }
         arrtransactionMode.push({ value: this.transactionModeValue, label: this.transactionModeValue, selected: this.selectedTransactionMode });
    });
    this.transactionModeSelect = arrtransactionMode;
    const operationType = Object.keys(OperationType);
    const arrOperationType = [];
    operationType.forEach((value, key) => {
      this.selectedOperationType = false;
      this.operationTypeValue = value;
        if (value === this.currentOperationType) {
            this.selectedOperationTypeValue = value;
            this.selectedOperationType = true;
        }
         arrOperationType.push({ value: this.operationTypeValue, label: this.operationTypeValue, selected: this.selectedOperationType });
    });
    this.operationTypeSelect = arrOperationType;


    const accountLedgerStatus = Object.keys(AccountStatus);
    const arrAccountLedgerStatus = [];
    accountLedgerStatus.forEach((value, key) => {
      this.selectedAccountLedgerStatus = false;
      this.accountLedgerStatusValue = value;
        if (value === this.currentAccountLedgerStatus) {
            this.selectedAccountLedgerStatusValue = value;
            this.selectedAccountLedgerStatus = true;
        }
         arrAccountLedgerStatus.push({ value: this.accountLedgerStatusValue, label: this.accountLedgerStatusValue, selected: this.selectedAccountLedgerStatus });
    });
    this.accountLedgerStatusSelect = arrAccountLedgerStatus;


    // this.transactionsService.getCountries().subscribe(
    //   (res: HttpResponse<any>) => {
    //       const countryArr = [];
    //       // if(this.currentCurrency === CurrencyType.EURO){

    //       // }
    //       _.forEach(res.body, (value, key) => {
    //           let selected = false;
    //           if (this.currentCurrency === CurrencyType.EURO) {
    //               selected = true;
    //               this.currentPayingWith = 'EURO-SEPA';
    //           } else if (this.currentCurrency === CurrencyType.GBP) {
    //               selected = true;
    //               this.currentPayingWith = 'GBP-FPS';
    //           }
    //           countryArr.push({ value: key, label: value.code, selected: selected });
    //       });

    //       this.CountriesOption = countryArr;
    //   },
    //   (res: HttpErrorResponse) => {}
    // );
  }

  submit({ value, valid }: { value: AddPaymentModel; valid: boolean }) {

    if(this.selectedFiat){
      value.inhouse=false;
    }

    this.transactionsService.setPayment(value).subscribe(
        result => {
            this.toasterService.success('Payment added successfully.');
            this.paymentModel.reset();
            this.paymentDate=null;
            this.checklimit=false;
            this.amount=null;
            this.txId=null;
            this.fiatRefrenceNumber=null;
            this.payingWithCurrency=null;
            this.currencyType=null;
            this.bank = null;
        },
        error => {
           this.processError(error);
            // console.log(error);
        }
    );
}

processError(response: HttpErrorResponse) {
     console.log(response.error.type);
    if (response.error.entityName === 'GauthDisableError') {
      this.toasterService.error(
        'Please enable your 2FA.'
    );
    }
    else if (response.error.entityName === 'paymentadded') {
      this.toasterService.error(
        'Payment for this refrence number is already added.'
    );
    }
    else if (response.error.entityName === 'depositrequestnotfount') {
      this.toasterService.error(
        'Deposit request for given refrence number not found.'
    );
    }
    else if (response.error.entityName === 'TransactionExistError') {
      this.toasterService.error(
        'Payment with this TxId already exist.'
    );
    } else if (response.error.errorKey==='gauthCodeInvalid') {
      this.toasterService.error(
        'Invalid 2FA code.'
    );
    } else{
    //  console.log(response.error);
      this.toasterService.error(response.error.title);
    }
}


changeCategory(category) {
  var selected = this.optionsSelect.find(x => x.label === category.label).value;
 if((selected ==='EURO') || (selected === 'GBP')){
  this.selectedFiat = true;
  }
  else{
    this.selectedFiat = false;
  }

}

checkKyclimit(refnumber){
 let limitCheck:CheckKycLimitModel = {
 paymentRefNum:refnumber,
 paymentDate:this.paymentDate
  }
  if(this.paymentDate!==null && refnumber!==null){
  this.transactionsService.checkDepositLimits(limitCheck).subscribe(
    result => {
       this.checklimit=true;
       this.kycDetail=result.body;

    },
    error => {
      this.checklimit=false;
       this.processError(error);

    }
);
}
}

}
