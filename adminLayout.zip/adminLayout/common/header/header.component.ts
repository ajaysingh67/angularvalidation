import { Component, OnInit } from '@angular/core';
import { SharedService } from '../../../service/shared.service';
import { Title } from '@angular/platform-browser';
import { Router, NavigationEnd, ActivatedRouteSnapshot } from '@angular/router';

@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    pageTitle: String = '';
	constructor(public _sharedservice: SharedService,private titleService: Title, private router: Router) { }
	
	private getPageTitle(routeSnapshot: ActivatedRouteSnapshot) {
        let title: String = routeSnapshot.data && routeSnapshot.data['title'] ? routeSnapshot.data['title'] : 'Admin';
        if (routeSnapshot.firstChild) {
            title = this.getPageTitle(routeSnapshot.firstChild) || title;
        }
        return title;
    }
	ngOnInit() {
		 this.titleService
		setTimeout(() => {}, 0);
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.pageTitle = this.getPageTitle(this.router.routerState.snapshot.root);
            }
        });
	}

	sidebarToggle() {
		const html = document.getElementsByTagName('body')[0];
		if (html.classList.contains('sidebar-open')) {
			html.classList.remove('sidebar-open');
		} else {
			html.classList.add('sidebar-open');
		}
	}

}
