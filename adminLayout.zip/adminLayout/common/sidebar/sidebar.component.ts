import { Component, OnInit } from '@angular/core';

declare interface RouteInfo {
  path: string;
  title: string;
  class: string;
}

export const ROUTES: RouteInfo[] = [
  { path: '/dashboard', title: 'Dashboard', class: '' },
  { path: '/users-list', title: 'Users List', class: '' },
  { path: '/customer-filter', title: 'Customer Filter', class: '' },
  { path: '/business-kyc', title: 'Business Customer KYC', class: '' },
  { path: '/individual-kyc', title: 'Individual Customer KYC', class: '' },
 
];
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  menuItems: any[];
  constructor() { }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
  }

}
