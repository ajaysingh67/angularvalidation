import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminLayoutRoutes } from './admin-layout.routes';
import { DashboardComponent } from '../../components/RouteComponent/dashboard/dashboard.component';
import { TransactionComponent } from '../../components/SingletonComponent/transaction/transaction.component';
import { DashboardService } from '../../service/dashboard/dashboard.service';
import { TimezonePipe } from '../../pipe/timezone/timezone.pipe';
i
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    NgbModule.forRoot(),
    ReactiveFormsModule,
    MDBBootstrapModulesPro.forRoot(),
    InputsModule, PreloadersModule
  ],
  declarations: [
    DashboardComponent,
  
    TimezonePipe,
   
  ],
  providers: [
   // DashboardService,
   // TicketsService,
  // ValidationmessageserviceService,
    ExpectedAmountPipe,
    TimezonePipe,
  ],
  schemas:[
    CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA
  ]
})

export class AdminLayoutModule {}
