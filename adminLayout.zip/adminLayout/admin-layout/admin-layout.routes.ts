import { Routes } from '@angular/router';
import { DashboardComponent } from '../../components/RouteComponent/dashboard/dashboard.component';
import { AuthGuard } from '../../service/interceptor/auth-guard.service';

export const AdminLayoutRoutes: Routes = [
    { path: 'dashboard', component: DashboardComponent, canActivate:[AuthGuard] ,data: {title: 'Dashboard'  } },
    { path: 'ticket-details/:id', component: TicketDetailsComponent, canActivate:[AuthGuard],data: {title: 'Ticket Details'  }  },
    { path: 'set-constraints', component: SetConstraintsComponent, canActivate:[AuthGuard],data: {title: 'Set Constraints'  }  },
  
];
