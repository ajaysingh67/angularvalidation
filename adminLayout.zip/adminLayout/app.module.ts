import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Injector } from '@angular/core';

import { AppComponent } from './app.component';
// MDB Module
import { MDBBootstrapModulesPro, MDBSpinningPreloader, ToastModule} from 'ng-uikit-pro-standard';
import { Routes, RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
// Routes
import { MultisignService } from './service/multisign/multisign.service';

const route: Routes = [
  {path: '', component: LoginComponent, data: {title: 'Sign in'} },
  // { path: 'UserDetails/:id', component: UserDetailsComponent },
  {
    path: 'dashboard',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  }, {
    path: '',
    component: AdminLayoutComponent,
    children: [
        {
      path: '',
      loadChildren: './layouts/admin-layout/admin-layout.module#AdminLayoutModule'
  }]}


];

@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(route),
    MDBBootstrapModulesPro.forRoot(),
    ToastModule.forRoot()
  ],
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    SidebarComponent,
    AdminLayoutComponent,
    ValidationMessageComponent,
    LoaderComponent,
    BusinessUserDetailsComponent
  
  ],
  providers: [
    MDBSpinningPreloader,
    ValidationmessageserviceService,
    SharedService,
    LoaderService,
    UsersService,
    DatePipe,
    ChatService,
    AuthGuard,
    ToastService,
    Web3Service,
    
    MultisignService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptedHttpService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoaderInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthExpiredInterceptor,
      multi: true,
      deps: [Injector, SharedService]
   },
    { provide: LocationStrategy,
      useClass: HashLocationStrategy,
    }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class AppModule { }
